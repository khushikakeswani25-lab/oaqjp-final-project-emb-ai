"""Call the Watson NLP service to detect emotions in a piece of text."""

import requests

WATSON_EMOTION_URL = (
    "https://sn-watson-emotion.labs.skills.network/"
    "v1/watson.runtime.nlp.v1/NlpService/EmotionPredict"
)
MODEL_ID = "emotion_aggregated-workflow_lang_en_stock"
EMOTION_NAMES = ("anger", "disgust", "fear", "joy", "sadness")


def _empty_result():
    """Return the standard result shape when analysis cannot be completed."""
    result = {emotion: None for emotion in EMOTION_NAMES}
    result["dominant_emotion"] = None
    return result


def emotion_detector(text_to_analyze):
    """Return the five emotion scores and their dominant emotion.

    A dictionary with None values is returned for HTTP 400 responses,
    unexpected HTTP statuses, request failures, or malformed API responses.
    """
    headers = {
        "grpc-metadata-mm-model-id": MODEL_ID,
    }
    input_json = {
        "raw_document": {
            "text": text_to_analyze,
        },
    }

    try:
        response = requests.post(
            WATSON_EMOTION_URL,
            json=input_json,
            headers=headers,
            timeout=30,
        )
    except requests.RequestException:
        return _empty_result()

    # Check the invalid-input status before processing successful responses.
    if response.status_code == 400:
        return _empty_result()

    if response.status_code != 200:
        return _empty_result()

    try:
        response_json = response.json()
        emotions = response_json["emotionPredictions"][0]["emotion"]
        scores = {emotion: float(emotions[emotion]) for emotion in EMOTION_NAMES}
    except (ValueError, TypeError, KeyError, IndexError):
        return _empty_result()

    scores["dominant_emotion"] = max(
        EMOTION_NAMES,
        key=scores.__getitem__,
    )
    return scores
