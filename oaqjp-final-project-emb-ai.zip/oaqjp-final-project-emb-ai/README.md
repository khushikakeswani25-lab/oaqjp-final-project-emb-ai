# Final Project

Emotion Detection application using the Watson NLP EmotionPredict API, Python, and Flask.

## Project structure

```text
oaqjp-final-project-emb-ai/
├── EmotionDetection/
│   ├── __init__.py
│   └── emotion_detection.py
├── static/
│   └── mywebscript.js
├── templates/
│   └── index.html
├── server.py
├── test_emotion_detection.py
├── requirements.txt
└── .gitignore
```

## Requirements

- Python 3.9 or later
- Internet access to reach the Watson NLP endpoint for live emotion predictions

## Setup

```bash
python3 -m venv .venv
source .venv/bin/activate      # Windows: .venv\\Scripts\\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## Run unit tests

The included unit tests mock the API response, so they can run without network access:

```bash
python3 -m unittest -v test_emotion_detection.py
```

## Run the web application

```bash
python3 server.py
```

Open `http://127.0.0.1:5000` in a browser. Enter a sentence and choose **Analyze emotion**. Live predictions require access to the Watson NLP endpoint configured in `EmotionDetection/emotion_detection.py`.

## API behavior

`emotion_detector(text_to_analyze)` returns a dictionary containing `anger`, `disgust`, `fear`, `joy`, `sadness`, and `dominant_emotion`. When the endpoint returns an HTTP 400 response or another unusable response, all dictionary values are `None` so the Flask app can show a clear invalid-input message.
