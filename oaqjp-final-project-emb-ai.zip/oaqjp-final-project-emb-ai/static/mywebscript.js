"use strict";

const form = document.getElementById("emotion-form");
const textInput = document.getElementById("textToAnalyze");
const responseBox = document.getElementById("system_response");
const analyzeButton = document.getElementById("analyze-button");

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const textToAnalyze = textInput.value.trim();

  if (!textToAnalyze) {
    responseBox.textContent = "Invalid text! Please try again.";
    return;
  }

  analyzeButton.disabled = true;
  responseBox.textContent = "Analyzing…";

  try {
    const url = `/emotionDetector?textToAnalyze=${encodeURIComponent(textToAnalyze)}`;
    const response = await fetch(url);
    const result = await response.text();
    // The server emits only fixed emotion labels and numeric scores in this response.
    responseBox.innerHTML = result;
  } catch (error) {
    responseBox.textContent = "Could not contact the application. Please try again.";
  } finally {
    analyzeButton.disabled = false;
  }
});
